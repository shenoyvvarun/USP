#include"header.h"
int debug = 1;
int debug1 = 1;
char states[2000]; long int s=-1; //states is the stack of states. s is the TOS

//int goal[DIM][DIM]={1,2,3,0}; //goal state
int goal[DIM][DIM]={1,2,3,4,5,6,7,8,0};
int count=0;

int solvable(int p[DIM][DIM],int r,int c) //doesn't change row and col so pointer not necessary
{
	//determine whether the state p is solvable 
	//return 1 if yes, 0 if not
	int i,j;
	int f=0; // inversions
	int x=0;
	for(i=1;i<(DIM*DIM);i++)
	{
		f+=less(p,i);
		printf("\n\nLess of %d : %d \n\n",i,less(p,i));
	}
	if((DIM%2)!=0)
	{
		if((f%2)==0)
			return 1;
		else 
			return 0;
	}
	else
	{
		for(i=(DIM-1);i>=0;i--)
		{
			for(j=0;j<DIM;j++)
			{
				if(p[i][j]==0)
				{
					x=DIM-i;					
				}
			}
		}
		if((x%2)==0)
		{
			if((f%2)!=0)
				return 1;
			else 
				return 0;
		}
		else
		{
			if((f%2)==0)
				return 1;
			else 
				return 0;
		}
	}
		
}

int position(int p[DIM][DIM],int i)
{
	//returns the position of number i in the matrix
	int c=0;
	int k,j;
	for(k=0;k<DIM;k++)
	{
		for(j=0;j<DIM;j++)
		{
			c++;
			if(p[k][j]==i)	
				return c;
		}
	}
	return -1; 
}
int less(int p[DIM][DIM],int i) 
{
	//returns the number of tiles j such that j<i and position(j)<position(i)
	int m,n=0;
	for(m=1;m<i;m++)
	{
		if(position(p,m)>position(p,i))
			n++;
	}
	return n;
}
	
int solvePuzzle(int p[DIM][DIM],int *r,int *c)
{
	int ret;
	char t;
	count++;
	if(debug) disp(p);
	if( isGoal(p))
	{
		printf("\n\nSOLVED!!\n\n");
		int i,j;
		//printf("\n\nNumber of moves: %d",count);
		disp(p);
		exit(0);
	}
	if(debug) printf("\nCalling isExist with r=%d c=%d\n",*r,*c);
	if(isExist(p,(*r),(*c)))
	{
		if(debug) printf("\n\nIN EXIST");
		reverseMove(p,r,c);
		return 0;
	}
	
	//down
	if(*r!=(DIM-1))
	{
		push('d'); count++;
		swap(&p[*r][*c],&p[*(r)+1][*c]);
		(*r)++;
		printf("\nMOVED DOWN");
		ret=solvePuzzle(p,r,c);
		if(ret==1) // return is 1 if all 4 moves are exhausted AFTER moving down. In this case,
		{
			push('u');
			swap(&p[*r][*c],&p[*(r)-1][*c]);
			(*r)--;
		}
	}
	
	//right
	if(*c!=(DIM-1))
	{
		push('r'); count++;
		swap(&p[*r][*c],&p[*r][*(c)+1]);
		(*c)++;
		printf("\nMOVED RIGHT");
		ret=solvePuzzle(p,r,c);
		if(ret==1)
		{
			push('l');
			swap(&p[*r][*c],&p[*r][*(c)-1]);
			(*c)--;
		}
	}
	
	//up
	if(*r!=0)
	{
		push('u'); 
		swap(&p[*r][*c],&p[*(r)-1][*c]);
		(*r)--;
		printf("\nMOVED UP");
		ret=solvePuzzle(p,r,c);
		if(ret==1)
		{
			push('d');
			swap(&p[*r][*c],&p[*(r)+1][*c]);
			(*r)++;
		}
	}
	
	//left
	if(*c!=0)
	{
		push('l'); count++;
		swap(&p[*r][*c],&p[*r][*(c)-1]);
		(*c)--;
		printf("\nMOVED LEFT");
		ret=solvePuzzle(p,r,c);
		if(ret==1)
		{
			push('r');
			swap(&p[*r][*c],&p[*r][*(c)+1]);
			(*c)++;
		}
	}
	return 1; // if all 4 moves from a position are exhausted, return 1. this is used to backtrack upward.
	
}

int isGoal(int p[DIM][DIM])
{
	int i,j;
	int c=1;

	for(i=0;i<DIM;i++)
	{
		for(j=0;j<DIM;j++)
		{
			if(p[i][j]!=goal[i][j])
				return 0;
			c++;
		}
	}
	return 1;
}

void swap(int* x,int* y)
{
	int temp=*x;
	*x=*y;
	*y=temp;
}

void reverseMove(int p[DIM][DIM],int *r,int *c)
{
	char pr;
	//  replace p with states[s] if doesnt work
	if(states[s]=='u')
	{
		swap(&p[*r][*c],&p[*(r)+1][*c]);
		(*r)++;
		//push('d');
		pr=pop();
	}
	else if(states[s]=='d')
	{
		swap(&p[*r][*c],&p[*(r)-1][*c]);
		(*r)--;
		//push('u');
		pr=pop();
	}
	else if(states[s]=='l')
	{
		swap(&p[*r][*c],&p[*r][*(c)+1]);
		(*c)++;
		//push('r');
		pr=pop();
	}
	else if(states[s]=='r')
	{
		swap(&p[*r][*c],&p[*r][*(c)-1]);
			(*c)--;
		//push('l');
		pr=pop();
	}

}
	


int isExist(int p[DIM][DIM],int r,int c)
{
	int i=0,j=0;
	int x=0;
	long int temp=s;
	int a[DIM][DIM];
	int aux;
	for(i=0;i<DIM;i++)
	{
		for(j=0;j<DIM;j++)
		{
			a[i][j]=p[i][j];
		}
	}
	i=0;
	j=0;
	while(temp!=(-1))
	{
		x=0;
		if(states[temp]=='u')
		{
			aux=a[r][c];
			a[r][c]=a[r+1][c];
			a[r+1][c]=aux;
			r++;
			//swap(&a[r][c],&a[r+1][c]);
			
		}
		else if(states[temp]=='d')
		{
			aux=a[r][c];
			a[r][c]=a[r-1][c];
			a[r-1][c]=aux;
			r--;
			//swap(&a[r][c],&a[r-1][c]);
		}
		else if(states[temp]=='l')
		{
			aux=a[r][c];
			a[r][c]=a[r][c+1];
			a[r][c+1]=aux;
			c++;
			//swap(&a[r][c],&a[r][c+1]);
		}
		else if(states[temp]=='r')
		{
			aux=a[r][c];
			a[r][c]=a[r][c-1];
			a[r][c-1]=aux;
			c--;
			//swap(&a[r][c],&a[r][c-1]);
		}
		temp--;
		printf("Temp was: %d   is: %d \n",temp+1,temp);
		for(i=0;i<DIM;i++)
		{
			for(j=0;j<DIM;j++)
			{
				if(a[i][j]!=p[i][j])
						x++;
				
			}
		}
		printf("%c\n",'a');
		disp(a);
		printf("\n\n");
		printf("%c\n",'p');
		disp(p);
		printf("\n\n");
		if(x==0)
		{
			printf("\nReturning 1");
			return 1;
		}
	}
	printf("\nReturning 0\n");
	return 0;
}

void push(char x)
{
	if(s>1999)
		printf("\n\nStack full");
	else
		states[++s]=x;
}
char pop()
{
	if(s==-1)
		printf("\n\nEmpty");
	else
		return states[s--];
}

void disp(int x[DIM][DIM])
{
	int i,j;
	if(debug1) printf("count : %d\n", count);
	#if 0
	for(i=0;i<DIM;i++)
	{
		for(j=0;j<DIM;j++)
		{
			printf("%d",x[i][j]);
		}
		printf("\n");
	}
	#endif
	//getchar();
}
