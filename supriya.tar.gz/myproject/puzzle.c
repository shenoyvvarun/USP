#include <stdio.h>
#include <stdlib.h>
#include "puzzle.h"
state_t start = { { '7', '6', '2', '5', '1', '3', '8', '4', ' '}, 2, 2, 0 };
//state_t goal = { { '7', '2', '6', '4', '1', '8', '5', ' ', '3'}, 2, 2, 0 };
state_t goal = { { '1', '2', '3', '4', '5', '6', '7', '8', ' '}, 2, 2, 0 };

state_t soln_list[MAXSIZE];
int n = 0;

int move_U(const state_t* src, state_t* dst)
{
	int r = src->r;
	int c = src->c;
        if(src->r == 0) return 0;
        *dst = *src;
        dst->fnindex = 0;
        dst->board[r][c] = dst->board[r - 1][c];
        dst->board[r - 1][c] = ' ';
        --dst->r;
        return 1;
}
int move_D(const state_t* src, state_t* dst)
{
	int r = src->r;
	int c = src->c;
        if(src->r == DIM - 1) return 0;
        *dst = *src;
        dst->fnindex = 0;
        dst->board[r][c] = dst->board[r + 1][c];
        dst->board[r + 1][c] = ' ';
        ++dst->r;
        return 1;
}
int move_L(const state_t* src, state_t* dst)
{
	int c = src->c;
	int r = src->r;
        if(src->c == 0) return 0;
        *dst = *src;
        dst->fnindex = 0;
        dst->board[r][c] = dst->board[r][c - 1];
        dst->board[r][c - 1] = ' ';
        --dst->c;
        return 1;
}
int move_R(const state_t* src, state_t* dst)
{
	int c = src->c;
	int r = src->r;
        if(src->c == DIM - 1) return 0;
        *dst = *src;
        dst->fnindex = 0;
        dst->board[r][c] = dst->board[r][c + 1];
        dst->board[r][c + 1] = ' ';
        ++dst->c;
        return 1;
}

int (*move[])(const state_t* src, state_t* dst) = { move_U, move_D, move_L, move_R};

long count  = 0;

void disp(const state_t* s)
{
	int i; int j;
	printf("count : %ld\n", count);
	for(i = 0; i < DIM; ++i)
	{
		for(j = 0; j < DIM; ++j)
		{
			printf("%3c ", s->board[i][j]);
		}
		printf("\n");
	}
//	if(debug) getchar();
}

int is_same(const state_t* lhs, const state_t* rhs)
{
	int i; int j;
	for(i = 0; i < DIM; ++i)
		for(j = 0; j < DIM; ++j)
			if(lhs->board[i][j] != rhs->board[i][j])
				return 0;
	return 1;
}

int is_repeated(const state_t* state)
{

	int i;
	for(i = 0; i < n; ++i)
	{
		if(is_same(&soln_list[i], state))
			return 1;
	}
	return 0;
}
void disp_soln()
{
	int i;
	for(i = 0; i < n; ++i)
	{
		printf(" ---- %d ---- \n", i);
		disp(&soln_list[i]);
	}
}


