#ifndef PUZZLE_H
#define PUZZLE_H
#define DIM 3
#define MAXSIZE 370000
extern int debug;
struct state
{
	char board[DIM][DIM];
	int r; int c;
	int fnindex;
};
typedef struct state state_t;
extern state_t start;
extern state_t goal;
int move_U(const state_t* src, state_t* dst);
int move_D(const state_t* src, state_t* dst);
int move_L(const state_t* src, state_t* dst);
int move_R(const state_t* src, state_t* dst);
extern int (*move[])(const state_t* src, state_t* dst);
extern long count;
void disp(const state_t*);

int is_same(const state_t*, const state_t*);


extern state_t soln_list[];
extern int n;

int is_repeated(const state_t*);
void disp_soln();



#endif
