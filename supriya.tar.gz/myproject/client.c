#include <stdio.h>
#include <stdlib.h>
#include "puzzle.h"
int debug = 0;
int debug1 = 1;
int m = 0; // move number
int main()
{
	state_t temp = start;
	int index;
	++m;
	soln_list[n++] = start;
	while(! is_same(&temp, &goal))
	{
		if(n > MAXSIZE)
		{
			printf("---max size reached---\n");
			exit(1);
		}
		if(debug1) printf("---- %d ---- \n", n);
		index = soln_list[n - 1].fnindex;
		if(index < 0 || index > 3)
		{
			printf("index : %d move %d n %d\n",
				index, m, n);
			getchar();
		}
		if(debug) printf(" making the move : %d\n", index);
		if(debug1) printf("move # : %d\n", ++m);
		if ((*move[index])(&soln_list[n -1], &temp) && 
			! is_repeated(&temp))
		{
			if(debug)
			{
				printf("added a move\n");
				disp(&temp);
			}
			temp.fnindex = 0;
			soln_list[n++] = temp;
		} 	
		else
		{
			while(n && ++soln_list[n - 1].fnindex == 4)
			{
				if(debug) printf("backtracks\n");
				--n;
			}
			if(n == 0)
			{
				printf("no soln\n"); exit(1);
			}
		}
	}
	printf("# of states : %d\n", n);
//	disp_soln();
#if 0
	//state_t s = { { '1', '2', '3', '4', ' ', '5', '6', '7', '8'}, 1, 1, 0 };
	state_t s = { { '1', '2', '3', '4', '8', '5', '6', '7', ' '}, 2, 2, 0 };

	state_t t;
	int i;
	disp(&s);
	for(i = 0; i < 4; ++i)
	{
		if( (*move[i])(&s, &t))
			disp(&t);
		else
			printf("cannot move\n");
	}

#endif
}
