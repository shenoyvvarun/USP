#include"header.h"
main()
{
	int row=2,col=2;
	#if 0
	int puz[DIM][DIM]={1,0,3,2,4,5,6,7,8}; // unsolvable.detects
	#endif
	
	#if 0
	int puz[DIM][DIM]={4,1,3,0,2,5,7,8,6}; // I created it by just tracking backward a few times from the goal. It gets solved.
	#endif
		
	#if 0
	int puz[DIM][DIM]={8,1,3,4,0,2,7,6,5}; //solvable, but again stops
	#endif
	
	#if 1
	int puz[DIM][DIM]={7,6,2,5,1,3,8,4,0}; //solvable, but again stops
	#endif
	
	#if 0
	int puz[DIM][DIM]={0,2,1,3};
	#endif
	
	#if 0
	int puz[DIM][DIM]={1,2,3,4,5,6,7,8,0};
	#endif
	if(!solvable(puz,row,col)) //doesn't change row and col so pointer not necessary
	{
		printf("\n\nNOT SOLVABLE");
		exit(0);
	}
	else
		solvePuzzle(puz,&row,&col);
	
}
