#include<stdio.h>
#include<stdlib.h>
#define DIM 3

int solvable(int p[DIM][DIM],int r,int c); //determines whether the passed state is solvable
//r and c represent the row and column number where the space is located

int position(int p[DIM][DIM],int i);

int less(int p[DIM][DIM],int i) ;

int solvePuzzle(int p[DIM][DIM],int*,int*); // to solve puzzle

int isGoal(int p[DIM][DIM]); //determine is state is at the goal

void reverseMove(int p[DIM][DIM],int*,int*);

void swap(int*,int*);

void push(char);

char pop();

void disp(int a[DIM][DIM]);


































