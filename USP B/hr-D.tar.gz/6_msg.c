// send a msg
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define KEY 0x1111

typedef struct msg
{
	long type;
	char name[20];

} msg_t;

int main()
{
	int id;
	msg_t m;
	id = msgget(KEY, IPC_CREAT  |  0600);	
	if(id < 0)
	{
		perror("msgget"); exit(1);
	}
	scanf("%ld %s", &m.type, m.name);
	if(msgsnd(id, &m, sizeof(msg_t) - sizeof(long), 0) < 0)
	{
		perror("msgsnd"); exit(2);
	}

}












