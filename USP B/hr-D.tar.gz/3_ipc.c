#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <time.h>


#define KEY 0x1111

int main()
{
	int id;
	struct msqid_ds m;
	id = msgget(KEY, IPC_CREAT |  0600);	
	if(id < 0)
	{
		perror("msgget"); exit(1);
	}
	if(msgctl(id, IPC_STAT, &m) < 0)
	{
		perror("msgctl"); exit(2);
	}
	printf("uid %d gid %d mode %o\n", m.msg_perm.uid,
		m.msg_perm.gid, m.msg_perm.mode);
	printf("send time : %s\n", ctime(&m.msg_stime));
	printf("recv time : %s\n", ctime(&m.msg_rtime));
	printf("change time : %s\n", ctime(&m.msg_ctime));

	printf("# of msg : %d\n", m.msg_qnum);
	printf("msgq size : %d\n", m.msg_qbytes);

}












