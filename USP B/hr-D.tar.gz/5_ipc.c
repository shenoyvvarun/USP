// remove ipc struct
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define KEY 0x1111

int main()
{
	int id;
	id = msgget(KEY, IPC_CREAT  |  0600);	
	if(id < 0)
	{
		perror("msgget"); exit(1);
	}
	if(msgctl(id, IPC_RMID, (struct msqid_ds*)0) < 0)
	{
		perror("msgctl"); exit(2);
	}
}












