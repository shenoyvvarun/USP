#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

// sys V IPC : interprocess communication mechanism
//	message queue
//	shared memory
//	semaphore

// communication mechanisms:
//	file
//	pipe 
//	named pipe
//	pipe open
//	signal

// no hierarchy
// all these are in memory - kernel data structures
//		persist until a reboot
// can be removed - will be removed immediately even if processes
//	are trying to hold on to it
// specify a number and not a name to identify

// how do we share an IPC?
// a) share the id
// b) share the key
// c) share the key creation
//	ftok("path", a small int)
//		path : root directory of the project
//		int : sequencing the IPC structures


// cmds :
//	ipcs
//	ipcrm

#define KEY 0x1111

int main()
{
	int id;
	id = msgget(KEY, IPC_CREAT | IPC_EXCL |  0600);	
	if(id < 0)
	{
		perror("msgget"); exit(1);
	}
}












