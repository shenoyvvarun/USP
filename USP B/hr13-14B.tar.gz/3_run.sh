echo "compiling ... "
gcc -c ${1}.c
echo "linking ..."
gcc ${1}.o -o ${1}
echo "running ..."
./${1}


