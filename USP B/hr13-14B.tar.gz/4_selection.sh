ls $1
#if test $? -eq 0
if [ $? -eq 0 ]
then
	echo $1 exists
else
	echo $1 does not exist
fi

