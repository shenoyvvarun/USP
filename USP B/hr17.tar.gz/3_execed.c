#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main()
{
	char ch;
	if(read(3, &ch, 1) < 0)
	{
		perror("read"); exit(1);
	}
	printf("char read : %c\n", ch);
	return 0;
}
