#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
// pid and ppid
int main()
{
	printf("execing proc : pid %d ppid %d\n",
		getpid(), getppid());
	if(execl("./5_execed", "5_execed", (void*)0) < 0)
	{
		perror("exec"); exit(1);
	}
	return 0;
}
