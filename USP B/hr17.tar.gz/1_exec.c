#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main()
{
	printf("before\n");
	// overlays the process calling it
	// overwrite the text segment
 	// overwrite the data segment
	//	start execution from the entry point in the text segment
	
	if(execl("/bin/ls", "ls", "-l", "-i", (void*)0) < 0)
	//if(execl("/bin/zzz", "ls", "-l", "-i", (void*)0) < 0)
	{
		perror("exec"); exit(1);
	}
	// will never be executed
	printf("after\n");
	return 0;
}
