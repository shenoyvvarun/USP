#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
// wait :
//	blocking call
//	makes the parent wait until a child comes back
//	pass a pointer to an int
//	is populated by the kernel based on what happened to the child

int main()
{
	int pid;	
	if( (pid = fork()) < 0)
	{
		perror("fork"); exit(1);
	}
	else if(pid)
	{
		// make parent wait for the child
		wait((int*)0);		
		printf("what : \n");
	}
	else
	{
		if(execl("/bin/ps", "ps", "-l", (void*)0) < 0)
		{
			perror("exec"); exit(2);
		}
	}
}
