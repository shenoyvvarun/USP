#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
typedef void (*sighandler_t)(int);
// SIG_DFL :  default handler
// SIG_IGN : ignore
// set handler : signal or sigaction
void handler(int signo)
{
	printf("signal recd : %d\n", signo);
	getchar();
	if( signal(SIGINT, SIG_DFL) == (sighandler_t)-1)
	{
		perror("signal"); exit(1);
	}
}
int main()
{
	if( signal(SIGINT, handler) == (sighandler_t)-1)
	{
		perror("signal"); exit(1);
	}
	while(1)
	{
		printf("hello ...\n");
	}
}
