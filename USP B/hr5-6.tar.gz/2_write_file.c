#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>


int main()
{
	int fd;
	int n = 20;
	int i;
	int sq;
	fd = open("sq.dat", O_WRONLY | O_CREAT , S_IRUSR | S_IWUSR | S_IRGRP);
	printf("fd : %d\n", fd);
	if(fd < 0)
	{
		perror("open  : ");
		exit(5);
	}
	for(i = 1; i <= n; ++i)
	{
		sq = i * i;
		if(write(fd, &sq, sizeof(int)) != sizeof(int))
			perror("write:"), exit(6);
	}
	close(fd);
	return 0;
}






