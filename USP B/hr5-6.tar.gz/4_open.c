#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>


int main()
{
	int fd;
	int fd1;
	int sq;
	int sq1;
	fd = open("sq.dat", O_RDONLY );
	printf("fd : %d\n", fd);
	fd1 = open("sq.dat", O_RDONLY );
	printf("fd1 : %d\n", fd1);
	read(fd, &sq, sizeof(int));	printf("%d\n", sq);
	close(fd);
	read(fd1, &sq1, sizeof(int));	printf("%d\n", sq1);
	close(fd1);
	return 0;
}






