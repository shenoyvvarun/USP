#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
// when a system call fails, it populates an int called errno

// creat:
//	does umask affect creation?
//	what if the file already exists?
//	is the permission changed?
//	can we change umask in a program?
//	what can be the arg for exit? can that be a big number?

int main()
{
	int fd;
	// index of an entry in the file descriptor table
	// part of the uarea of the process
	//fd = creat("junk.dat", S_IRUSR | S_IWUSR | S_IRGRP);
	fd = creat(".", S_IRUSR | S_IWUSR | S_IRGRP);
	printf("fd : %d\n", fd);
	if(fd < 0)
	{
		printf("creat failed\n");
		printf("errno : %d\n", errno);
		if(errno == EISDIR)
		{
			printf("is a directory being opened as a file\n");
		}
		// get meaningful error message
		perror("create  : ");
		exit(5);
	}
	close(fd);
	return 0;
}






