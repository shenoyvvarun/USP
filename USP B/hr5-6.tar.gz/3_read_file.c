#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>


int main()
{
	int fd;
	int sq;
	int size;
	fd = open("sq.dat", O_RDONLY );
	printf("fd : %d\n", fd);
	if(fd < 0)
	{
		perror("open  : ");
		exit(5);
	}
	while((size = read(fd, &sq, sizeof(int))) == sizeof(int))
	{
		printf("%d\t", sq);
	}
	close(fd);
	return 0;
}






