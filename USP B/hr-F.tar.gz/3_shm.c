// shared memory
//	access from shared memory
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

// sharing based on the key
#define KEY 0x2222
int main()
{
	int id;
	struct shmid_ds s;
	int* p;
	int n = 5;
	int i;
	id = shmget(KEY, 1000, IPC_CREAT | 0666);
	if(id < 0)
	{
		perror("shmget"); exit(1);
	}
	p = (int*)shmat(id, 0, 0); // similar to malloc
	if(p == (void*)-1)
	{
		perror("shmat"); exit(1);
	}
	printf("p : %p\n", p);
	for(i = 0; i < n; ++i)
	{
		printf("%d\t",	p[i]);
	}
	printf("\n");
	if( shmdt(p) == -1)
	{
		perror("shmdt"); exit(2);
	}
	return 0;
}
