// shared memory
//	create a linked list
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
struct node
{
	int key;
	struct node* link;
};
typedef struct node node_t;
void disp(node_t *temp)
{
	while(temp)
	{
		printf("%d\t", temp->key);
		temp = temp->link;
	}
	printf("\n");
}
#define KEY 0x2222
int main()
{
	int id;
	node_t* p;
	node_t* q;
	int n = 5;
	int i;
	id = shmget(KEY, 1000, IPC_CREAT | 0666);
	if(id < 0)
	{
		perror("shmget"); exit(1);
	}
	p = (node_t*)shmat(id, 0, 0); // similar to malloc
	if(p == (void*)-1)
	{
		perror("shmat"); exit(1);
	}
	printf("p : %p\n", p);
	p->key = 100;
	p->link = p + 1;
	p->link->key = 200;
	p->link->link = 0;
	disp(p);
	q = (node_t*)shmat(id, 0, 0); // similar to malloc
	if(q == (void*)-1)
	{
		perror("shmat"); exit(1);
	}
	printf("q : %p\n", q);
	disp(q);
	if( shmdt(p) == -1)
	{
		perror("shmdt"); exit(2);
	}
	if( shmdt(q) == -1)
	{
		perror("shmdt"); exit(2);
	}
	return 0;
}
