// shared memory
//	multiple attach will cause different sets of virtual addresses
//		to be mapped to the same physical addresses
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define KEY 0x2222
int main()
{
	int id;
	struct shmid_ds s;
	int* p;
	int* q;
	int n = 5;
	int i;
	id = shmget(KEY, 1000, IPC_CREAT | 0666);
	if(id < 0)
	{
		perror("shmget"); exit(1);
	}
	p = (int*)shmat(id, 0, 0); // similar to malloc
	if(p == (void*)-1)
	{
		perror("shmat"); exit(1);
	}
	printf("p : %p\n", p);
	q = (int*)shmat(id, 0, 0); // similar to malloc
	if(q == (void*)-1)
	{
		perror("shmat"); exit(1);
	}
	printf("q : %p\n", q);
	for(i = 0; i < n; ++i)
	{
		p[i] = i * i ;
	}
	for(i = 0; i < n; ++i)
	{
		printf("%d\t", q[i]);
	}
	printf("\n");
	if( shmdt(p) == -1)
	{
		perror("shmdt"); exit(2);
	}
	if( shmdt(q) == -1)
	{
		perror("shmdt"); exit(2);
	}
	return 0;
}
