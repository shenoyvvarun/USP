#! /bin/bash
echo "a : $a"
a=arecanut
echo "a : $a"

# source:
# modify the variables of the current shell
# csh : source
# ksh | bash :  .


