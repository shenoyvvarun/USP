#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
union semun {
               int              val;    /* Value for SETVAL */
               struct semid_ds *buf;    /* Buffer for IPC_STAT, IPC_SET */
               unsigned short  *array;  /* Array for GETALL, SETALL */
               struct seminfo  *__buf;  /* Buffer for IPC_INFO
                                           (Linux-specific) */
};

#define KEY 0x4321
int main()
{
	int id;
	struct semid_ds s;
	union semun u;
	u.buf = &s;
	id = semget(KEY, 3, IPC_CREAT | 0666);
	if(id < 0)
	{
		perror("semget"); exit(1);
	}
	if(semctl(id, 0, IPC_STAT, u ) < 0)
	{
		perror("semctl"); exit(2);
	}
	printf("otime : %s\n", ctime(&s.sem_otime));
	printf("ctime : %s\n", ctime(&s.sem_ctime));
	printf("# of sem: %d\n", s.sem_nsems);




}
