#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

struct msg
{
	long type; // must
	int n;
};
typedef struct msg msg_t;

#define KEY 0x1235
int main()
{
	int id;
	msg_t mymsg;
	if((id = msgget(KEY, IPC_CREAT | 0666)) < 0)
	{
		perror("msgget"); exit(1);
	}
	printf("enter type & number : ");
	scanf("%ld %d", &mymsg.type, &mymsg.n);
	if(msgsnd(id, &mymsg, sizeof(mymsg) - sizeof(long), 0) < 0)
	{
		perror("msgsnd: "); exit(2);
	}


	return 0;
}


