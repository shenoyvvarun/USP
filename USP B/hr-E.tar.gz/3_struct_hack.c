// structure hack
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct what
{
	int n;
	char s[1];
};

typedef struct what what_t;

int main()
{
	what_t *p;
	char s[] = "this is a test";
	p = (what_t *)malloc(sizeof(what_t) + strlen(s) + 1 - 1);
	p->n = 1111;
	strcpy(p->s, s);
	printf("%d %s\n", p->n, p->s);
}
