#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

struct msg
{
	long type; // must
	int n;
};
typedef struct msg msg_t;

#define KEY 0x1235
int main()
{
	int id;
	msg_t mymsg;
	long type;
	if((id = msgget(KEY, IPC_CREAT | 0666)) < 0)
	{
		perror("msgget"); exit(1);
	}
	printf("enter the type : ");
	scanf("%ld", &type);
	if(msgrcv(id, &mymsg, sizeof(msg_t) - sizeof(long), 
		type, 0) < 0)
	{
		perror("msgrcv"); exit(2);
	}
	printf("msg : %d\n", mymsg.n);
	return 0;
}
// recv:
//	gets the first message of the specified type
//      if no such message, recv will block
//		unless we specify IPC_NOWAIT
//	if type is specified as 0, we can read messages in chronological 
//		order












