// shared memory
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define KEY 0x2222
int main()
{
	int id;
	struct shmid_ds s;
	id = shmget(KEY, 1000, IPC_CREAT | 0666);
	if(id < 0)
	{
		perror("shmget"); exit(1);
	}
	if(shmctl(id, IPC_STAT, &s) < 0)
	{
		perror("shmctl"); exit(2);
	}
	printf("size of memory : %d\n", s.shm_segsz);
	printf("attach time : %s", ctime(&s.shm_atime));
	printf("detach time : %s", ctime(&s.shm_dtime));
	printf("change time : %s", ctime(&s.shm_ctime));
	printf("# of attach : %d\n", s.shm_nattch);



	
}
