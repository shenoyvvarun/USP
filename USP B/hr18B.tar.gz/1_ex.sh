# variables
# variable of the parent process is not available to the child
# variable the child creates is not available in the parent

# special variables are also available in the child
#	created using command in shell called export
#	are called environmental variables
#	what if the child modifies the variable?
echo "a : $a"
b="bat"
echo "b : $b"
echo "PATH : $PATH"
echo "c : $c"
c="coat"
echo "c : $c"




