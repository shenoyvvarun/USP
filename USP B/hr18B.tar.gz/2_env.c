/*
environmental variables are available to the child process
changing in child does not affect the parent
stored as key=value pairs
getenv setenv
*/
#include <stdio.h>
#include <stdlib.h>

int main()
{
	char* s;
	s = getenv("c");
	printf("s : %s\n", s);
	//setenv("c", "curry", 0);
	setenv("c", "curry", 1);
	s = getenv("c");
	printf("s : %s\n", s);
}
