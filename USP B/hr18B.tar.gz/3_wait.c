// creating a zombie
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>

int main()
{
	int pid;
	pid = fork();
	if(pid < 0)
	{
		perror("fork"); exit(1);
	}
	else if(pid)
	{
		printf("parent starts\n");
		sleep(10000);
		printf("parent ends\n");
	}
	else
	{
		printf("child starts\n");
		printf("child ends\n");
	}
}

