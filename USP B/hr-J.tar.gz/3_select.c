#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>

int main()
{
	struct timeval t = {5, 500000  }; // 5 and half sec 
	printf("experimenting on timeout\n");
	if(select(1024, (fd_set*)0, (fd_set*)0, (fd_set*)0,&t) == -1)
	{
		perror("select"); exit(1);
	}
	printf("timed out\n");

}

