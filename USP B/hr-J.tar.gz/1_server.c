#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
// SOCK_STREAM : 	protocol : tcp; connection is maintained
//			server : creation of queue
//			once the client connects,
//				server tracks the client
// SOCD_DGRAM : 	protocol : udp; connection is not maintained
//			no queue creation on server
int main()
{
	int sd;
	struct sockaddr_in s;
	int sl;


	int m;
	int sqm;

	sd = socket(AF_INET, SOCK_DGRAM, 0); 
	if(sd == -1)
	{
		perror("socket"); exit(1);
	}
	printf("socket : %d\n", sd);
	s.sin_family = AF_INET;
	s.sin_addr.s_addr = htonl(INADDR_ANY); 
	s.sin_port = htons(3333);
	sl = sizeof(s);

	if(bind(sd, (struct sockaddr*)&s, sl) == -1)
	{
		perror("bind"); exit(2);
	}
	printf("bind successful\n");
	while(1)
	{
	// mistake was here; was using cd which was not initialized
        // earlier
		if(recvfrom(sd, (void*)&m, sizeof(int), 0,
			(struct sockaddr*)&s, &sl ) == -1)
		{
			perror("recv"); exit(5);
		}
		printf("recd : %d\n", m);
		sleep(rand() % 5);
		sqm = m * m;
		printf("sending %d\n", sqm);
		if(sendto(sd, (void*)&sqm, sizeof(int), 0, 
			(struct sockaddr*)&s, sl) == -1)
		{
			perror("send"); exit(6);
		}
	}
	
}


