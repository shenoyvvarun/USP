#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>

int main()
{
	int cd;
	struct sockaddr_in c;
	int cl;

	int n;
	int sqn;

	cd = socket(AF_INET, SOCK_DGRAM, 0); // default : udp
	if(cd == -1)
	{
		perror("socket"); exit(1);
	}
	printf("socket : %d\n", cd);
	
	c.sin_family = AF_INET;
	c.sin_port = htons(3333);
	c.sin_addr.s_addr = htonl(INADDR_ANY);
	cl = sizeof(c);
	srand(getpid());
	n = rand() % 100;
	printf("Sending %d\n", n);
	if(sendto(cd, (void*)&n, sizeof(int), 0,
		(struct sockaddr*)&c, cl) == -1)
	{
		perror("send"); exit(3);
	}
	sleep(rand() % 5);
	if(recvfrom(cd, (void*)&sqn, sizeof(int), 0,
		(struct sockaddr*)&c, &cl) == -1)
	{
		perror("recv"); exit(4);
	}
	printf("square of %d is %d\n", n, sqn);


	

}
