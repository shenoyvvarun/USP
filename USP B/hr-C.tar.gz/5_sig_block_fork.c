#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
void handler_INT(int signo)
{
	printf("recd SIGINT\n");
}
void handler_QUIT(int signo)
{
	printf("recd SIGQUIT\n");
}
// sleep is interrupted on signal
int main()
{
	sigset_t sig_block;
	sigset_t sig_old;
	sigset_t sig_pending;
	int pid;

	// no check for error
	signal(SIGINT, handler_INT);
	signal(SIGQUIT, handler_QUIT);
	
	// populate sig_block
	sigemptyset(&sig_block);
	sigaddset(&sig_block, SIGINT);
	sigaddset(&sig_block, SIGQUIT);

	printf("pgm begins\n");
	sleep(10);
	if(sigprocmask(SIG_BLOCK ,&sig_block, &sig_old) < 0)
	{
		perror("sig block\n"); exit(1);
	}
	printf("enter critical section\n");
	sleep(10);
	// check for pending signals
	if(sigpending(&sig_pending) < 0)
	{
		perror("sigpending"); exit(3);
	}
	printf("sigint : %d\n", sigismember(&sig_pending, SIGINT));
	printf("sig quit : %d\n", sigismember(&sig_pending, SIGQUIT));
	// creating the child process
	if((pid = fork()) < 0)
	{
		perror("fork"); exit(4);
	}
	else if (pid == 0)
	{
		// to check blocking
		sigset_t temp; sigset_t res;
		sigemptyset(&temp);
		sigprocmask(SIG_BLOCK, &temp, &res);
		printf("child : sigint : %d\n", sigismember(&res, SIGINT));
		printf("child : sig quit : %d\n", sigismember(&res, SIGQUIT));
	}
	else
	{
		sleep(10);
		printf("Exit critical secction\n");
		if(sigprocmask(SIG_SETMASK , &sig_old, (sigset_t*)0) < 0)
		{
			perror("sig block\n"); exit(2);
		}
		sleep(10);
		printf("pgm ends\n");
	}
}
// once the critical section is exited,
//	pending signals are handled
//	order is not defined
//	if there are multiple occurrences of the same signal,
//		it will be handled only once


