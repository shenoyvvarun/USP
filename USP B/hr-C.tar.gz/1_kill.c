#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>

int main()
{
	int pid;
	pid = fork();
	if(pid < 0)
	{
		perror("fork"); exit(1);
	}
	else if(pid)
	{
		sleep(5);
		// send a signal to the child
		printf("sending a signal\n");
		if(kill(pid, SIGINT) < 0)
		{
			perror("kill"); exit(2);
		}
		printf("sent the signal\n");
		sleep(5);
	}
	else
	{
		while(1)
		{
			printf("I will not die\n");
		}
	}

}
