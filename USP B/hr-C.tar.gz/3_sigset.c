#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
// sigset_t : interface; type ; use it in blocking of signals in the uarea
int main()
{
	sigset_t s;
	// clear all  bits
	sigemptyset(&s);
	printf("has SIGINT : %d\n", sigismember(&s, SIGINT));
	printf("has SIGQUIT : %d\n", sigismember(&s, SIGQUIT));
	sigaddset(&s, SIGINT);
	printf("has SIGINT : %d\n", sigismember(&s, SIGINT));
	printf("has SIGQUIT : %d\n", sigismember(&s, SIGQUIT));

}
