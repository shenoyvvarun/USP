#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>

int main()
{
	int pid;
	pid = fork();
	if(pid < 0)
	{
		perror("fork"); exit(1);
	}
	else if(pid)
	{
		sleep(5);
		// send a signal to the child
		printf("sending a signal\n");
		// committing suicide 
		// raise : wrapper for this
		if(kill(getpid(), SIGINT) < 0)
		{
			perror("kill"); exit(2);
		}
		printf("sent the signal\n");
		sleep(5);
	}
	else
	{
		printf("will sleep now\n");
		sleep(5);
	}
}
