# suppress the output
if ls $1 >/dev/null 2>&1
then
	echo exists
else
	echo does not exist
fi

