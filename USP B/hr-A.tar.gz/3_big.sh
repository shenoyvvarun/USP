# find the biggest file
# ls -l 
# remove the first line
# ls -l | sed '1d' 
# squeeze white space
# ls -l | sed '1d' | tr -s  " "
# pick up 5th and 9th fields
# ls -l | sed '1d' | tr -s  " " | cut -d" "  -f5,9
# sort
# ls -l | sed '1d' | tr -s  " " | cut -d" "  -f5,9 | sort -n -r
# pickup the first line
# ls -l | sed '1d' | tr -s  " " | cut -d" "  -f5,9 | sort -n -r | head -1
# pickup the name
#ls -l | sed '1d' | tr -s  " " | cut -d" "  -f5,9 | sort -n -r | head -1 | cut -d" " -f2

#rm `ls -l | sed '1d' | tr -s  " " | cut -d" "  -f5,9 | sort -n -r | head -1 | cut -d" " -f2`


ls -l | sed '1d' | tr -s  " " | cut -d" "  -f5,9 | sort -n -r | tee out | head -1 | cut -d" " -f2


# cmd1 | cmd2 | ... | cmd n-1 | cmd n
# all cmds cmd2 .. cmd n -1 should be filters
# takes input from stdin and outputs to stdout




# useful commands
# 1. tail
# 2. head
# 3. sed

