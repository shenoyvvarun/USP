#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main()
{
	int fd[2];
	int pid;
	if(pipe(fd) < 0)
	{
		perror("pipe"); exit(1);
	}
	if( (pid = fork()) < 0)
	{
		perror("fork"); exit(2);
	}
	else if(pid) // parent
	{
		close(fd[0]);
		sleep(5);
		if(write(fd[1], "testing", 8) < 0)
		{
			perror("write");
		}
	}
	else // child
	{
		char buffer[10];
		close(fd[1]);
		if(read(fd[0], buffer, 10) < 0)
		{
			perror("read");
		}
		printf("read : %s\n", buffer);
	}
	
}
