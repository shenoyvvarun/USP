#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <sys/un.h>
#include <string.h>

int main()
{
	int cd;
	struct sockaddr_un c;
	int cl;

	int n;
	int sqn;

	cd = socket(AF_UNIX, SOCK_STREAM, 0); // default : tcp
	if(cd == -1)
	{
		perror("socket"); exit(1);
	}
	printf("socket : %d\n", cd);
	
	c.sun_family = AF_UNIX;
	strcpy(c.sun_path, "mysocketfile");
	cl = sizeof(c);
	if(connect(cd, (struct sockaddr*) &c, cl) == -1)
	{
		perror("connect"); exit(2);
	}
	srand(getpid());
	n = rand() % 100;
	printf("Sending %d\n", n);
	if(send(cd, (void*)&n, sizeof(int), 0) == -1)
	{
		perror("send"); exit(3);
	}
	sleep(rand() % 5);
	if(recv(cd, (void*)&sqn, sizeof(int), 0) == -1)
	{
		perror("recv"); exit(4);
	}
	printf("square of %d is %d\n", n, sqn);


	

}
