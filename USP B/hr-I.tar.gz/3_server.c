#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>

int main()
{
	int sd;
	struct sockaddr_in s;
	int sl;

	int cd;
	struct sockaddr_in c;
	int cl;

	int m;
	int sqm;

	sd = socket(AF_INET, SOCK_STREAM, 0); // default : tcp
	if(sd == -1)
	{
		perror("socket"); exit(1);
	}
	printf("socket : %d\n", sd);
	s.sin_family = AF_INET;
	s.sin_addr.s_addr = htonl(INADDR_ANY); 
	s.sin_port = htons(2222);
	sl = sizeof(s);

	if(bind(sd, (struct sockaddr*)&s, sl) == -1)
	{
		perror("bind"); exit(2);
	}
	printf("bind successful\n");
	if(listen(sd, 5) == -1)
	{
		perror("listen"); exit(3);
	}
	cl = sizeof(c);
	while(1)
	{
		if((cd = accept(sd, (struct sockaddr*)&c, &cl )) == -1)
		{
			perror("accept"); exit(4);
		}
		if(recv(cd, (void*)&m, sizeof(int), 0) == -1)
		{
			perror("recv"); exit(5);
		}
		printf("recd : %d\n", m);
		sleep(rand() % 5);
		sqm = m * m;
		printf("sending %d\n", sqm);
		if(send(cd, (void*)&sqm, sizeof(int), 0) == -1)
		{
			perror("send"); exit(6);
		}
	}
	
}


