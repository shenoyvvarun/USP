#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/stat.h>
// try synchronizing using mutex; does not work
int main()
{
	int pid;
	char ch;
	pthread_mutex_t m;
	pthread_mutex_init(&m, 0);
	srand(getpid());
	pid = fork();
	if(pid < 0)
	{
		perror("fork"); exit(1);
	}
	else if(pid)
	{
		for(ch = 'A'; ch <= 'Z'; ++ch)
		{
			sleep(rand() % 2);
			pthread_mutex_lock(&m);
			putchar(ch);
			fflush(stdout);
			sleep(rand() % 2);
			putchar(ch);
			fflush(stdout);
			pthread_mutex_unlock(&m);
			sleep(rand() % 2);
		}
	}
	else
	{
		for(ch = 'a'; ch <= 'z'; ++ch)
		{
			sleep(rand() % 2);
			pthread_mutex_lock(&m);
			putchar(ch);
			fflush(stdout);
			sleep(rand() % 2);
			putchar(ch);
			fflush(stdout);
			pthread_mutex_unlock(&m);
			sleep(rand() % 2);
		}
	}
	pthread_mutex_destroy(&m);
}


