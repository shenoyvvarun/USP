#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

int main()
{
	int id;
	id = msgget(IPC_PRIVATE, IPC_CREAT | 0666);
	if(id < 0)
	{
		perror("msgget"); exit(1);
	}
	printf("%d %d\n", IPC_PRIVATE, id);
}

