#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
// make the two processes execute alternately
#define KEY1 1111
#define KEY2 2222
union semun
{
	int val;
};
int main()
{
	int pid;
	char ch;
	int id1;
	int id2;
	union semun u;
	struct sembuf p = { 0, -1, SEM_UNDO };
	struct sembuf v = { 0, +1, SEM_UNDO };
	if((id1 = semget(KEY1, 1, IPC_CREAT | 0666)) == -1)
	{
		perror("semget"); exit(11);
	}
	if((id2 = semget(KEY2, 1, IPC_CREAT | 0666)) == -1)
	{
		perror("semget"); exit(12);
	}
	u.val = 1;
	if(semctl(id1, 0, SETVAL, u) < 0)
	{
		perror("semctl"); exit(13);
	}
	u.val = 0;
	if(semctl(id2, 0, SETVAL, u) < 0)
	{
		perror("semctl"); exit(13);
	}

	srand(getpid());
	pid = fork();
	if(pid < 0)
	{
		perror("fork"); exit(1);
	}
	else if(pid)
	{
		for(ch = 'A'; ch <= 'Z'; ++ch)
		{
			sleep(rand() % 2);
			if(semop(id1, &p, 1) < 0)
			{
				perror("semwait"); exit(43);
			}
			putchar(ch);
			fflush(stdout);
			sleep(rand() % 2);
			putchar(ch);
			fflush(stdout);
			if(semop(id2, &v, 1) < 0)
			{
				perror("semwait"); exit(43);
			}
			sleep(rand() % 2);
		}
	}
	else
	{
		for(ch = 'a'; ch <= 'z'; ++ch)
		{
			sleep(rand() % 2);
			if(semop(id2, &p, 1) < 0)
			{
				perror("semwait"); exit(43);
			}
			putchar(ch);
			fflush(stdout);
			sleep(rand() % 2);
			putchar(ch);
			fflush(stdout);
			if(semop(id1, &v, 1) < 0)
			{
				perror("semwait"); exit(43);
			}
			sleep(rand() % 2);
		}
	}
}


