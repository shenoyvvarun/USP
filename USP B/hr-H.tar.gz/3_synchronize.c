#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/ipc.h>
#include <sys/shm.h>
// try synchronizing using mutex in shared memory
// should get back
#define KEY 0x2222
int main()
{
	int pid;
	char ch;
	int id;
	pthread_mutex_t *p;
	pthread_mutexattr_t a;
	pthread_mutexattr_settype(&a, PTHREAD_PROCESS_SHARED);
	id = shmget(KEY, 0x100, IPC_CREAT | 0666);
	p = (pthread_mutex_t*)shmat(id, 0, 0);
	pthread_mutex_init(p, &a);
	srand(getpid());
	pid = fork();
	if(pid < 0)
	{
		perror("fork"); exit(1);
	}
	else if(pid)
	{
		sleep(5);
		for(ch = 'A'; ch <= 'Z'; ++ch)
		{
			sleep(rand() % 2);
			pthread_mutex_lock(p);
			putchar(ch);
			fflush(stdout);
			sleep(rand() % 2);
			putchar(ch);
			fflush(stdout);
			pthread_mutex_unlock(p);
			sleep(rand() % 2);
		}
	}
	else
	{
		for(ch = 'a'; ch <= 'z'; ++ch)
		{
			sleep(rand() % 2);
			pthread_mutex_lock(p);
			putchar(ch);
			fflush(stdout);
			sleep(rand() % 2);
			putchar(ch);
			fflush(stdout);
			pthread_mutex_unlock(p);
			sleep(rand() % 2);
		}
	}
}


