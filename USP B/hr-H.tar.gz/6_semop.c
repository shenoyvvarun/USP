#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#define KEY 0x1234
union semun
{
	unsigned short*  array;
};
int main()
{
	int id;
	union semun u;
	unsigned short a[] = {3, 4, 5};
	struct sembuf s[3] = {
		{ 0, 0, SEM_UNDO },
		{ 1, 0, SEM_UNDO },
		{ 2, 0, SEM_UNDO },
	
	}; 
	id = semget(KEY, 3, IPC_CREAT | 0666);
	if(id < 0)
	{
		perror("semget"); exit(1);
	}
	u.array = a;
	if(semctl(id, 0, SETALL, u) < 0)
	{
		perror("semctl"); exit(2);
	}
	scanf("%d %d %d", &s[0].sem_op, &s[1].sem_op, &s[2].sem_op);
	if(semop(id, s, 3) == -1)
	{
		perror("semop"); exit(3);
	}
	printf("succeeded\n");
	
}
