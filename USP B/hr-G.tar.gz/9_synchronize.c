#include <stdio.h>
#include <fcntl.h>     
#include <sys/stat.h>  
#include <unistd.h>
#include <stdlib.h>
#include <semaphore.h>

// not working !!
int main()
{
	int pid;
	char ch;
	sem_t *p;
	p = sem_open("my_sem1", O_CREAT, 0666, 1);
	if(p == SEM_FAILED)
	{
		perror("sem init"); exit(41);
	}
	srand(getpid());
	pid = fork();
	if(pid < 0)
	{
		perror("fork"); exit(1);
	}
	else if(pid)
	{
		for(ch = 'A'; ch <= 'Z'; ++ch)
		{
			sleep(rand() % 2);
			if(sem_wait(p) < 0)
			{
				perror("semwait"); exit(43);
			}
			putchar(ch);
			fflush(stdout);
			sleep(rand() % 2);
			putchar(ch);
			fflush(stdout);
			if(sem_post(p) < 0)
			{
				perror("sempost"); exit(44);
			}
			sleep(rand() % 2);
		}
	}
	else
	{
		for(ch = 'a'; ch <= 'z'; ++ch)
		{
			sleep(rand() % 2);
			if(sem_wait(p) < 0)
			{
				perror("semwait"); exit(43);
			}
			putchar(ch);
			fflush(stdout);
			sleep(rand() % 2);
			putchar(ch);
			fflush(stdout);
			if(sem_post(p) < 0)
			{
				perror("sempost"); exit(44);
			}
			sleep(rand() % 2);
		}
	}
	if(sem_destroy(p) < 0)
	{
		perror("sem destroy"); exit(42);
	}
}


