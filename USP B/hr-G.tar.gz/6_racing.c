#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
int main()
{
	int pid;
	char ch;
	srand(getpid());
	pid = fork();
	if(pid < 0)
	{
		perror("fork"); exit(1);
	}
	else if(pid)
	{
		for(ch = 'A'; ch <= 'Z'; ++ch)
		{
			sleep(rand() % 2);
			putchar(ch);
			fflush(stdout);
			sleep(rand() % 2);
			putchar(ch);
			fflush(stdout);
			sleep(rand() % 2);
		}
	}
	else
	{
		for(ch = 'a'; ch <= 'z'; ++ch)
		{
			sleep(rand() % 2);
			putchar(ch);
			fflush(stdout);
			sleep(rand() % 2);
			putchar(ch);
			fflush(stdout);
			sleep(rand() % 2);
		}
	}
}


