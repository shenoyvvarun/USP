#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <semaphore.h>
// not working !!
int main()
{
	int pid;
	char ch;
	sem_t s;
	if(sem_init(&s, 1, 1) < 0)
	{
		perror("sem init"); exit(41);
	}
	srand(getpid());
	pid = fork();
	if(pid < 0)
	{
		perror("fork"); exit(1);
	}
	else if(pid)
	{
		for(ch = 'A'; ch <= 'Z'; ++ch)
		{
			sleep(rand() % 2);
			if(sem_wait(&s) < 0)
			{
				perror("semwait"); exit(43);
			}
			putchar(ch);
			fflush(stdout);
			sleep(rand() % 2);
			putchar(ch);
			fflush(stdout);
			if(sem_post(&s) < 0)
			{
				perror("sempost"); exit(44);
			}
			sleep(rand() % 2);
		}
	}
	else
	{
		for(ch = 'a'; ch <= 'z'; ++ch)
		{
			sleep(rand() % 2);
			if(sem_wait(&s) < 0)
			{
				perror("semwait"); exit(43);
			}
			putchar(ch);
			fflush(stdout);
			sleep(rand() % 2);
			putchar(ch);
			fflush(stdout);
			if(sem_post(&s) < 0)
			{
				perror("sempost"); exit(44);
			}
			sleep(rand() % 2);
		}
	}
	if(sem_destroy(&s) < 0)
	{
		perror("sem destroy"); exit(42);
	}
}


