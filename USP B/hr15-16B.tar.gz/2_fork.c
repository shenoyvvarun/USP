#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
int main()
{
	int pid;
	printf("nooru\n");
	pid = fork();
	// code below executed by the parent and the child
	printf("saavira\n");
	return 0;
}
