#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
int a = 111;
int* ptr;
int main()
{
	int pid;
	int g = 10;
	ptr = &a;
	printf("pointer to a : %p\n", ptr);
	pid = fork();
	if(pid < 0)
	{
		perror("fork"); exit(1);
	}
	else if(pid) // parent
	{
		printf("parent  : %d\n", *ptr);
		*ptr = 222;
	}
	else // child
	{
		printf("child : %d\n", *ptr);
		*ptr = 333;
	}
	printf("end :  %d\n", *ptr);
	return 0;
}

// virtual address of global variable remains same in both the
// parent and the child

// fork returns true in parent and false in child
// pids of parent and child are not same
// ppids of parent and child are not same
// virtual addr is replicated
// offsets to the variable remain same
// variables in data segment are inherited
//	child can also use those values
// physically location is shared until one of the processes
//	modifies -  a new page is created - copy on write
// global variables are not shared









