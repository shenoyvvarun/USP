#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
int main()
{
	int pid;
	pid = fork();
	if(pid < 0)
	{
		perror("fork"); exit(1);
	}
	else if(pid) // parent
	{
		printf("parent pid: %d ppid %d\n", 
			getpid(), getppid());
		sleep(2);
	}
	else // child
	{
		printf("child pid: %d ppid %d\n", 
			getpid(), getppid());
	}
	return 0;
}
// fork:
//	returns the pid of the child in the parent
//	and 0 in the child
