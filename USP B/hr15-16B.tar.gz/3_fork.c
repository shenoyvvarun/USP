#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
int main()
{
	int pid;
	printf("nooru\n");
	pid = fork();
	printf("result : %d\n", pid);
	// code below executed by the parent and the child
	printf("saavira\n");
	return 0;
}
// fork:
//	returns the pid of the child in the parent
//	and 0 in the child
