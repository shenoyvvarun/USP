echo "compiling ..."
gcc -c x.c
echo "linking ..."
gcc x.o -o x
echo "running ..."
./x


