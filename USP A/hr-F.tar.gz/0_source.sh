#! /bin/bash
# export : sets the environmental variable
echo "a: $a"
a=ass
echo "a : $a"
# execed or child process cannot change the environment of the execing process or parent respectively

# modify variables(environment) in the same shell
#	source or .



